# -*- coding: utf-8 -*-
"""
Created on Sat May  9 15:00:50 2020

@author: yashesh
"""

"""
import cv2
import requests #used to call the such as api, html etc.
import numpy as np
import json
import argparse
import signal #Set handlers for asynchronous events
import logging #Logging is a means of tracking events that happen when some software runs. The software’s developer adds logging calls to their code to indicate that certain events have occurred. An event is described by a descriptive message which can optionally contain variable data.
import datetime, time"""

import PIL.Image
import PIL.ImageTk
from tkinter import *
#import tkinter as tk
import cv2,os 
import csv
import numpy as np
import pandas as pd
import time
import datetime
#window = tk.Tk()
try:
    window = Tk()
    window.geometry('600x600')
    window.resizable(width=False, height=False)
    window.title("My Attendance Portal")
    window.configure(background='#D0D3D4')
    image=PIL.Image.open("logo.png")
    photo=PIL.ImageTk.PhotoImage(image)
    #lab=tk.Label(image=photo,bg='#D0D3D4')
    lab= Label(image=photo,bg='#D0D3D4')
    lab.pack()

    fn=StringVar()
    entry_name=Entry(window,textvar=fn)
    entry_name.place(x=150,y=257)
    ln=StringVar()
    entry_id=Entry(window,textvar=ln)
    entry_id.place(x=455,y=257)
    dn=StringVar()
    v = StringVar()
    
    label2=Label(window,text="New User",fg='#717D7E',bg='#D0D3D4',font=("roboto",20,"bold")).place(x=20,y=200)
    label3=Label(window,text="Enter Name :",fg='black',bg='#D0D3D4',font=("roboto",15)).place(x=20,y=250)
    label4=Label(window,text="Enter Roll Number :",fg='black',bg='#D0D3D4',font=("roboto",15)).place(x=275,y=252)
    label5=Label(window,text="Attendence System",fg='red',bg='#D0D3D4',font=("roboto",15)).place(x=20,y=100)
    status=Label(window,textvariable=v,fg='red',bg='#D0D3D4',font=("roboto",15,"italic")).place(x=20,y=150)
    label6=Label(window,text="Already a User ?",fg='#717D7E',bg='#D0D3D4',font=("roboto",20,"bold")).place(x=20,y=350)
    
except IOError:
        print('An error occurred trying to read the file.')

except ValueError:
    print('Non-numeric data found in the file.')
    
except ImportError:
    print ("NO module found")
    
except EOFError:
    print('Why did you do an EOF on me?')
    
except KeyboardInterrupt:
    print('You cancelled the operation.')
    
except:
    print("Unexpected error:", sys.exc_info()[0])
    raise
        



#Our code structure is defined such
#Block starts
def insert_user():
    try:
        Id=ln.get()
        name=fn.get()
        if(Id.isnumeric() and name.isalpha()):
            df=pd.read_csv("StudentDetails.csv", low_memory=False, delimiter=',')
            if(df is not None and not df.empty and df['Id'].astype(str).str.contains(str(Id)).any()==True):
                v.set("User already exists")
            else:
                harcascadePath = "haarcascade_frontalface_default.xml"
                detector=cv2.CascadeClassifier(cv2.data.haarcascades + harcascadePath)
                cam = cv2.VideoCapture(0)
                if cam.isOpened():
                    sampleNum=0
                    while(True):
                        ret, img = cam.read()
                        if np.shape(img) != ():
                            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                            faces = detector.detectMultiScale(gray, 1.3, 5)
                            for (x,y,w,h) in faces:
                                cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                                #Incrementing sample number
                                sampleNum=sampleNum+1
                                
                                #Saving the captured face in the dataset folder TrainingImage
                                cv2.imwrite("TrainingImage\ "+name.lower() +"."+Id +'.'+ str(sampleNum) + ".jpg", gray[y:y+h,x:x+w])
                                #Display the frame
                                cv2.imshow('frame',img)
                                print(sampleNum)
                                #wait for 100 miliseconds
                                if cv2.waitKey(100) & 0xFF == ord('q'):
                                    break
                                # Break if the sample number is morethan 100
                                elif sampleNum>60:
                                    cam.release()
                                    cv2.destroyAllWindows()
                                    row = [Id , name]
                                    with open('StudentDetails.csv','a+') as csvFile:
                                        writer = csv.writer(csvFile)
                                        writer.writerow(row)
                                        print('Row Inserted')
                                    csvFile.close()
                                    name_saved=" ID : "+str(Id)+ " with NAME : "+ name +" Saved"
                                    v.set(name_saved)
    except IOError:
        print('An error occurred trying to read the file.')

    except ValueError:
        print('Non-numeric data found in the file.')
    
    except ImportError:
        print ("NO module found")
    
    except EOFError:
        print('Why did you do an EOF on me?')
    
    except KeyboardInterrupt:
        print('You cancelled the operation.')
    except cv2.error as e:
        print(e)
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise
            
#Block Ends
            
# Train Image Start
def train_image():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    harcascadePath = "haarcascade_frontalface_default.xml"
    #detector =cv2.CascadeClassifier(harcascadePath)
    detector=cv2.CascadeClassifier(cv2.data.haarcascades + harcascadePath)
    faces,Id = ImagesAndNames("TrainingImage")
    recognizer.train(faces, np.array(Id))
    recognizer.save("recognizers/Trainner.yml")
    v.set("Images Trained")
#end trained Image

#image and name return start
def ImagesAndNames(path):
    #get the path of all the files in the folder
    imagePaths=[os.path.join(path,f) for f in os.listdir(path)]
    #create empty face list
    faces=[]
    #create empty ID list
    Ids=[]
    #now looping through all the image paths and loading the Ids and the images
    for imagePath in imagePaths:
        #Loading the images in Training images and converting it to gray scale
        g_image=PIL.Image.open(imagePath).convert('L')
        #Now we are converting the PIL image into numpy array
        image_ar=np.array(g_image,'uint8')
            #getting the Id from the image
        Id=int(os.path.split(imagePath)[-1].split(".")[1])
        # extract the face from the training image sample
        faces.append(image_ar)
        Ids.append(Id)
    return faces,Ids
#image and name return end
    
#track user
def track_user():
    try:
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        recognizer.read("recognizers/Trainner.yml")
        harcascadePath = "haarcascade_frontalface_default.xml"
        cam = cv2.VideoCapture(0)
        #detector=cv2.CascadeClassifier(harcascadePath)
        detector=cv2.CascadeClassifier(cv2.data.haarcascades + harcascadePath)
        if cam.isOpened():
            font=cv2.FONT_HERSHEY_SIMPLEX
            df=pd.read_csv("StudentDetails.csv", low_memory=False, delimiter=',')
            col_names = ['ID','Date','Time']
            attendance = pd.DataFrame(columns = col_names)
            while(True):
                ret, img = cam.read()
                if np.shape(img) != ():
                    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                    faces = detector.detectMultiScale(gray, 1.3, 5)
                    for (x,y,w,h) in faces:
                        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                        Id, conf = recognizer.predict(gray[y:y+h,x:x+w])
                        name=df.loc[df['Id'] == Id]['Name'].values
                        name_get=str(Id)+"-"+name
                        time_s = time.time()
                        date = str(datetime.datetime.fromtimestamp(time_s).strftime('%Y-%m-%d'))
                        timeStamp = datetime.datetime.fromtimestamp(time_s).strftime('%H:%M:%S')
                        attendance.loc[len(attendance)] = [Id,date,timeStamp]
                        if(conf>90):
                            noOfFile=len(os.listdir("ImagesUnknown"))+1
                            cv2.imwrite("ImagesUnknown\Image"+str(noOfFile) + ".jpg", img[y:y+h,x:x+w])
                            Id='Unknown'
                            name_get=str(Id)
                        cv2.putText(img,str(name_get),(x+w,y+h),font,0.5,(0,255,255),2,cv2.LINE_AA)
                        attendance=attendance.drop_duplicates(keep='first',subset=['ID'])
                        fileName="Attendance/in.json"
                        attendance.to_json(fileName,orient="index")
                        cv2.imshow('img',img)
                        if (cv2.waitKey(100)==ord('q')):
                            break
                        cam.release()
                        cv2.destroyAllWindows()
                        v.set("Images tracked ")
    except IOError:
        print('An error occurred trying to read the file.')

    except ValueError:
        print('Non-numeric data found in the file.')
    
    except ImportError:
        print ("NO module found")
    
    except EOFError:
        print('Why did you do an EOF on me?')
    
    except KeyboardInterrupt:
        print('You cancelled the operation.')
    except cv2.error as e:
        print(e)
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise

#end track user
            
    

button2=Button(window,text="Submit",width=5,fg='#fff',bg='#27AE60',relief=RAISED,font=("roboto",15,"bold"),command=insert_user)
button2.place(x=20,y=300)
button3=Button(window,text="Train Images",fg='#fff',bg='#5DADE2',relief=RAISED,font=("roboto",15,"bold"),command=train_image)
button3.place(x=100,y=300)
button4=Button(window,text="Make Attendence",fg='#fff',bg='#E67E22',relief=RAISED,font=("roboto",15,"bold"),command=track_user)
button4.place(x=20,y=400)

  
window.mainloop()           